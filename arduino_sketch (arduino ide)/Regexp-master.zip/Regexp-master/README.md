Regexp
======

Regular expression parser for microcontrollers based on the Lua one.

Documentation on interfacing with the library, and other details at:

http://www.gammon.com.au/forum/?id=11063

## Documentation on regular expressions (Lua patterns)

* [Official Lua documentation](http://www.lua.org/manual/5.2/manual.html#6.4.1)

* [Simplified documentation from MUSHclient help](http://www.gammon.com.au/scripts/doc.php?lua=string.find)
